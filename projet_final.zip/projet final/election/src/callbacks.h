#include <gtk/gtk.h>


void
on_t1_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_t2_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_t3_toggled                          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_aff_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajout_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treels_row_activated                (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_re_clicked                          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_listadd_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_vote1_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_main_liste_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treecond_row_activated              (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_modif_liste_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajout_cond_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_vote2_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Return_liste_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_listes_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_stat_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_suprimer_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_recherche_bv_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher1_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongestinbvajouter_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongestinbvmodifier_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttongestionbvsupprimer_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_stat_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonretourgestionbv_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobuttonajouter40_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonajouter20_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonajouter10_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonajouterok_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_ajouter_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_modif1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_modif2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_modif3_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_modif1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonok_modifier_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonannuler_modifier_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_taux_obs_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_afficher_stat_gagne_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_stat_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button75_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobuttonajouter40_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonajouter20_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonajouter10_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_modif1_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_modif2_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_modif3_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobuttonajouter20_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
